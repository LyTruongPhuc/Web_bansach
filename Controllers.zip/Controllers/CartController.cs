﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using ShopCartMVC.Data;
using ShopCartMVC.Models.Entities;
using System.Collections.Generic;
using System.Linq;
using Newtonsoft.Json;

namespace ShopCartMVC.Controllers
{
    public class CartController : Controller
    {
        private readonly ApplicationDbContext db;

        public CartController(ApplicationDbContext context)
        {
            db = context;
        }

        public IActionResult Index()
        {
            var cart = GetCart();
            return View(cart);
        }

        [HttpPost]
        [ValidateAntiForgeryToken] // Bảo vệ CSRF

        public IActionResult AddToCart(int productId, int quantity = 1)
        {
            var product = db.Products.Find(productId);
            if (product == null) return NotFound();

            var cart = GetCart();
            var cartItem = cart.FirstOrDefault(c => c.ProductId == productId);

            if (cartItem != null)
            {
                cartItem.Quantity += quantity;
            }
            else
            {
                cart.Add(new CartItem
                {
                    ProductId = product.Id,
                    ProductName = product.Name,
                    Price = product.Price,
                    Quantity = quantity
                });
            }

            SaveCart(cart);
            int cartCount = cart.Sum(c => c.Quantity); // Tính tổng số lượng sản phẩm trong giỏ

            return Json(new { success = true, cartCount }); // Trả về JSON để cập nhật giao diện
        }


        public IActionResult UpdateCart(int productId, int quantity)
        {
            var cart = GetCart();
            var cartItem = cart.FirstOrDefault(c => c.ProductId == productId);

            if (cartItem != null && quantity > 0)
            {
                cartItem.Quantity = quantity;
            }

            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public IActionResult RemoveFromCart(int productId)
        {
            var cart = GetCart();
            cart.RemoveAll(c => c.ProductId == productId);
            SaveCart(cart);
            return RedirectToAction("Index");
        }

        public IActionResult Checkout()
        {
            return View();
        }
        public IActionResult GetCartCount()
        {
            var cart = GetCart();
            int count = cart.Sum(c => c.Quantity);
            return Json(new { count });
        }
        public IActionResult OrderHistory()
        {
            var orders = db.Orders
                           .OrderByDescending(o => o.Id)
                           .ToList();

            // Load OrderDetails cho mỗi đơn
            foreach (var order in orders)
            {
                order.OrderDetails = db.OrderDetails
                                       .Where(od => od.OrderId == order.Id)
                                       .ToList();

                // Load thêm Product nếu cần
                foreach (var detail in order.OrderDetails)
                {
                    detail.Product = db.Products.FirstOrDefault(p => p.Id == detail.ProductId);
                }
            }

            return View(orders);
        }


        [HttpPost]
        public IActionResult Checkout(string customerName, string address, string phone)
        {
            var cart = GetCart();
            if (cart.Count == 0)
            {
                ViewBag.Error = "Giỏ hàng của bạn đang trống!";
                return View();
            }

            var order = new Order
            {
                CustomerName = customerName,
                Address = address,
                Phone = phone,
                OrderDetails = cart.Select(c => new OrderDetail
                {
                    ProductId = c.ProductId,
                    Quantity = c.Quantity,
                    Price = c.Price
                }).ToList()
            };

            db.Orders.Add(order);
            db.SaveChanges();

            ClearCart();
            ViewBag.Success = "Đặt hàng thành công!";
            return View();
        }

        private List<CartItem> GetCart()
        {
            var cart = HttpContext.Session.GetString("Cart");
            return cart == null ? new List<CartItem>() : JsonConvert.DeserializeObject<List<CartItem>>(cart);
        }

        private void SaveCart(List<CartItem> cart)
        {
            HttpContext.Session.SetString("Cart", JsonConvert.SerializeObject(cart));
        }

        private void ClearCart()
        {
            HttpContext.Session.Remove("Cart");
        }
    }

    public class CartItem
    {
        public int ProductId { get; set; }
        public string ProductName { get; set; }
        public decimal Price { get; set; }
        public int Quantity { get; set; }
    }
}
