﻿using Microsoft.AspNetCore.Mvc;
using ShopCartMVC.Data;
using System.Linq;

namespace ShopCartMVC.Controllers
{
    public class HomeController : Controller
    {
        private readonly ApplicationDbContext db;

        public HomeController(ApplicationDbContext context)
        {
            db = context;
        }
        [HttpGet]
        public JsonResult Search(string term)
        {
            var products = db.Products
                .Where(p => p.Name.Contains(term))
                .Select(p => new { p.Id, p.Name, p.ImageUrl })
                .Take(10)
                .ToList();

            return Json(products);
        }


        public IActionResult Index()
        {
            // Lấy 3 sản phẩm mới, hot, bán chạy
            var newProducts = db.Products
                                .Where(p => p.IsNew)
                                .OrderByDescending(p => p.Id)
                                .Take(3)
                                .ToList();

            var hotProducts = db.Products
                                .Where(p => p.IsHot)
                                .OrderByDescending(p => p.Id)
                                .Take(3)
                                .ToList();

            var bestSellers = db.Products
                                .OrderByDescending(p => p.SoldCount)
                                .Take(10)
                                .ToList();

            ViewBag.NewProducts = newProducts;
            ViewBag.HotProducts = hotProducts;
            ViewBag.BestSellers = bestSellers;

            return View();
        }
    }
}
