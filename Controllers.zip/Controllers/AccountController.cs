﻿using Microsoft.AspNetCore.Mvc;
using ShopCartMVC.Data;
using ShopCartMVC.Models.Entities;
using System.Security.Cryptography;
using System.Text;

namespace ShopCartMVC.Controllers
{
    public class AccountController : Controller
    {
        private readonly ApplicationDbContext _db;

        public AccountController(ApplicationDbContext db)
        {
            _db = db;
        }

        public IActionResult Login() => View();

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            string hashedPassword = GetMD5(password);
            var user = _db.Users.FirstOrDefault(u => u.Username == username && u.Password == hashedPassword);

            if (user != null)
            {
                // Lưu thông tin vào Session
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("Username", user.Username);

                return RedirectToAction("Index", "Home");
            }

            ViewBag.Error = "Sai tài khoản hoặc mật khẩu!";
            return View();
        }

        public IActionResult Register() => View();

        [HttpPost]
        public IActionResult Register(User user, string FullName)
        {
            // Kiểm tra tài khoản đã tồn tại chưa
            if (_db.Users.Any(u => u.Username == user.Username))
            {
                ViewBag.Error = "Tài khoản đã tồn tại!";
                return View();
            }

            // Kiểm tra FullName (tránh NULL)
            if (string.IsNullOrWhiteSpace(FullName))
            {
                ViewBag.Error = "Vui lòng nhập họ và tên!";
                return View();
            }

            user.FullName = FullName; // Gán giá trị từ form
            user.Password = GetMD5(user.Password);

            _db.Users.Add(user);
            _db.SaveChanges();
            return RedirectToAction("Login");
        }

        public IActionResult Logout()
        {
            HttpContext.Session.Clear(); // Xóa tất cả dữ liệu trong Session
            return RedirectToAction("Index", "Home");
        }

        private string GetMD5(string input)
        {
            using (MD5 md5 = MD5.Create())
            {
                byte[] bytes = md5.ComputeHash(Encoding.UTF8.GetBytes(input));
                return string.Concat(bytes.Select(b => b.ToString("x2")));
            }
        }
    }
}
