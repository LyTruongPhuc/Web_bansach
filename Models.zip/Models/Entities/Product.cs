﻿using System.ComponentModel.DataAnnotations;

namespace ShopCartMVC.Models.Entities
{
    public class Product
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }

        public string ImageUrl { get; set; }

        public decimal Price { get; set; }
        public string Description { get; set; }
        public bool IsHot { get; set; } // Sản phẩm hot
        public bool IsNew { get; set; } // Sản phẩm mới
        public int SoldCount { get; set; } // Sản phẩm bán chạy
        public string AgeGroup { get; set; }

    }
}
