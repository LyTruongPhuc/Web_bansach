﻿$(document).ready(function () {
    $(".add-to-cart").click(function () {
        var productId = $(this).data("id");
        var token = $('input[name="__RequestVerificationToken"]').val(); // Lấy token

        $.ajax({
            url: "/Cart/AddToCart",
            type: "POST",
            data: { productId: productId, __RequestVerificationToken: token },
            success: function (response) {
                if (response.success) {
                    $("#cart-count").text(response.cartCount);
                    alert("Sản phẩm đã thêm vào giỏ hàng!");
                }
            },
            error: function () {
                alert("Có lỗi xảy ra! Vui lòng thử lại.");
            }
        });
    });
});
